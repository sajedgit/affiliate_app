
<div class="row">
	<div class="col-12">


		<?php shailan_dropdown_menu( ); ?><br/><br/>


	</div>
</div>