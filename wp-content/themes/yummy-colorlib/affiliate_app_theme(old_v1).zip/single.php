<?php get_header(); ?>

<?php get_sidebar('single_page_header'); ?>

 

<?php get_sidebar('single_blog'); ?>

 
 

<?php get_footer() ?>



