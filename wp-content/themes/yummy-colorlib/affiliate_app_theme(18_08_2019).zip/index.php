<?php get_header(); ?>

<?php //get_sidebar('welcome-post'); ?>

<?php get_sidebar('sticky'); ?>

<?php get_sidebar('category') ?>

<?php get_sidebar('blog') ?>

<?php //get_sidebar('portfolio'); ?>

<?php //get_sidebar('social'); ?>

<?php get_footer() ?>



